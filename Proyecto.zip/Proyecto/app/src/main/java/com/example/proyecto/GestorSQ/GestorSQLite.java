package com.example.proyecto.GestorSQ;

public class GestorSQLite {
}
