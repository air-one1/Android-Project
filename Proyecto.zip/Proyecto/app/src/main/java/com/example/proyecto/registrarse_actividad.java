package com.example.proyecto;

public class registrarse_actividad {
}
